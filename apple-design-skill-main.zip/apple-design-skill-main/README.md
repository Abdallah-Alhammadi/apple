# Apple Design Skill

[![Static Badge](https://img.shields.io/badge/Nutshell_Engineering-Internal-green?logo=okta)](https://github.com/search?q=org%3ANutshellEngineering+topic%3Ainternal&type=repositories)
[![Apache License 2.0](https://img.shields.io/:license-Apache%20License%202.0-blue.svg?style=shield)](https://github.com/TomRegan/comparatorverifier/blob/main/LICENSE.md)

Human interface guidelines for coding agents, grounded in Apple's design principles.

![Apple Design Skill](assets/apple-design-skill.webp)

An [Agent Skill](https://agentskills.io) that gives coding agents grounded, up-to-date guidance from Apple's Human
Interface Guidelines (HIG) for designing, building, and reviewing native UI/UX across iOS, iPadOS, macOS, watchOS,
tvOS, and visionOS — components, input methods, foundational design elements (color, typography, materials, motion,
accessibility), interaction patterns, per-platform considerations, and platform technologies. It also includes
workflows for generative tasks like designing a new component or composing a whole screen, not just answering
one-off questions.

## Installing as a Claude Code plugin

This repository also doubles as a Claude Code plugin marketplace (`.claude-plugin/marketplace.json` and
`.claude-plugin/plugin.json` at the repo root), so it can be installed and updated like any other plugin instead of
copying files by hand:

```
/plugin marketplace add https://github.com/NutshellEngineering/apple-design-skill
/plugin install apple-design-skill@apple-design-skill-marketplace
```

For local testing, `<path-or-url-to-this-repo>` can be a filesystem path (e.g. `.` from this directory); for sharing
with others, push this repo to a git host and use its URL or `owner/repo` shorthand instead.

## Structure

The portable skill package lives in [`skills/apple-design-skill/`](skills/apple-design-skill/) (the directory name
matches the skill's `name:` field, per the [Agent Skills spec](https://agentskills.io)):

- `skills/apple-design-skill/SKILL.md` — the skill definition: frontmatter metadata, when to use it, and the
  workflows an agent follows.
- `skills/apple-design-skill/references/` — the mirrored HIG content (Getting started, Foundations, Patterns,
  Components, Inputs, Technologies) plus `topic-index.md`, a flattened lookup of every article.

To use this skill with an Agent Skills-compatible client, point it at the `skills/apple-design-skill/` directory (or
copy that directory into wherever your client discovers skills).

## License

The original material in this repository — `skills/apple-design-skill/SKILL.md`,
`skills/apple-design-skill/references/topic-index.md`, and other project files we authored — is licensed under the
Apache License, Version 2.0. See [LICENSE.md](LICENSE.md).

This license does **not** extend to the mirrored Apple documentation described below.

## Disclaimer

`skills/apple-design-skill/references/` contains an **unofficial mirror** of Apple's Human Interface Guidelines, extracted via
[sosumi.ai](https://sosumi.ai). All Human Interface Guidelines content, imagery, and trademarks belong to **Apple
Inc.** This project is not affiliated with, endorsed by, or sponsored by Apple. It's provided for reference and
educational purposes only, on an "as is" basis with no warranty of accuracy or completeness.

The mirrored content may lag behind or diverge from Apple's official guidelines. Always consult the authoritative,
current documentation at [developer.apple.com/design/human-interface-guidelines](https://developer.apple.com/design/human-interface-guidelines)
before shipping a design decision. If you are Apple, or represent Apple, and would like this content removed or
amended, please open an issue.
